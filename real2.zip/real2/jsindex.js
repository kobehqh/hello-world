
$(document).ready(function(){
    $("#clickhide").click(function(){
        $("#hide").css("display","none");
        $("#show").css("display","block");
    })


    $("#imgChange").change(function(){
        var file=this.files[0];
        var type=file.type;
        if(type=="image/jpg" || type=="image/png" || type=="image/jpeg"){
            if(window.FileReader);
            var reader = new FileReader();
            reader.readAsDataURL(file);
            reader.onloadend = function (e) {
                $("#Img").attr("src",e.target.result);
            };
        }
        else{
            alert("请输入jpg、jpeg、png图片类型 ");
            $("#hide").css("display","block");
            $("#show").css("display","none");
        }
    })




    $("input.number-input").change(function(){
        if($("input.number-input").val().length!=11){
            alert("请输入正确的手机号");
            $("input.btn").attr("disabled",true);
        }
        else if($("input.number-input").val().length=11){
            $("input.btn").removeAttr("disabled");
        }
    })


})









