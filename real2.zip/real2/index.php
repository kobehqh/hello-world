<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" name="viewport" content="user-scalable=no">
    <title>牧野王庭</title>
    <link href="cssindex.css" rel="stylesheet" type="text/css"/>
    <script type="text/javascript" src="http://ajax.microsoft.com/ajax/jquery
/jquery-1.4.min.js"></script>
    <link href="//at.alicdn.com/t/font_407313_esij4orxaya54s4i.css" rel="stylesheet" type="text/css"/>
    <script src="jsindex.js"></script>

</head>
<body>
    <header class="header">
        <img class="img" src="./images/fl-banner.jpg"/>
    </header>

<form action="" method="get" >

    <div class="main">
        <p class="font-top">新生手机号码预填</p>
        <p class="font-middle">提交成功后,即可领取办卡福利</p>


        <div class="main-number">
            <i class="iconfont icon-xuanxiang icon-color1" style="font-size: 4rem"></i>
            <div class="icon-font">手机号码</div>
            <input type="text" placeholder="请填写您新办理的手机号码"  class="number-input"/>
        </div>


        <div class="main-id">
            <i class="iconfont icon-tupian  icon-color2" style="font-size: 4rem"></i>
            <div class="icon-font adjust">上传截图</div>




            <div class="copy" id="clickhide">
                <input type="file" class="copy-input" id="imgChange" />
            </div>

            <div class="show-img" id="show">
                <img id="Img" class="img-adjust"/>
            </div>


            <div class="upload" id="hide" >
                <div class="upload-img">
                    <i class="iconfont icon-jiahao icon-color3" style="font-size: 10em"></i>
                </div>
                <div class="upload-font">请上传您办理手机卡订单截图</div>
                <p class="upload-select">(选填)</p>
            </div>

        </div>

        <div class="sub">
            <input type="button" value="提交" class="btn"/>
        </div>

        <p class="foot">
            *推广福利需新办号码验证码验证后才可领取
        </p>
    </div>
</form>

</body>
</html>